package com.juliluli19.nequiglickhapk

abstract class Operacion (val numero1:Double, val numero2: Double) {
    protected var resultado:Double=0.0

    abstract fun operar()

    fun imprimir(){
        println("Resultado: $resultado")
    }
}
