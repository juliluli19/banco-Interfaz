package com.juliluli19.nequiglickhapk

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton


class Tramites : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tramites)

        val botontrans = findViewById<ImageButton>(R.id.botontransferencia)
        val botonagregar= findViewById<ImageButton>(R.id.botonagregar)
        val botonperfil = findViewById<ImageButton>(R.id.botonperfil)
        val botonregresar = findViewById<ImageButton>(R.id.botonregresar)


        botonregresar.setOnClickListener {

            val intent = Intent(this, Tramites::class.java)
            startActivity(intent)
        }

    }
}