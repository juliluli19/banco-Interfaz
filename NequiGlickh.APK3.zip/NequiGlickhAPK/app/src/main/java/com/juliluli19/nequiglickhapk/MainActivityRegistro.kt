package com.juliluli19.nequiglickhapk

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivityRegistro: AppCompatActivity() {
    @SuppressLint("SuspiciousIndentation")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_registro)

        val idPerfil = findViewById<EditText>(R.id.editTextIdPerfil2)
        val numero = findViewById<EditText>(R.id.editTextNumero2)
        val nombre = findViewById<EditText>(R.id.editTextNombre2)
        val clave = findViewById<EditText>(R.id.editTextContrasena2)

        val botonRegistrar = findViewById<Button>(R.id.buttonRegistrar2)


            botonRegistrar.setOnClickListener{
                val adminSQLlite = AdminSQLlite(this, "MisPerfiles", null,1)
                val bd = adminSQLlite.writableDatabase
                val registro = ContentValues()
                registro.put("idPerfil",idPerfil.text.toString())
                registro.put("numero",numero.text.toString())
                registro.put("contrasena",clave.text.toString())
                registro.put("nombre",nombre.text.toString())
                bd.insert("perfiles",null, registro)
                bd.close()

                idPerfil.setText("")
                numero.setText("")
                nombre.setText("")
                clave.setText("")
                Toast.makeText(this,"El producto fue reguistrado", Toast.LENGTH_LONG).show()
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            }

    }
}