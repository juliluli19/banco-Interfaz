package com.juliluli19.nequiglickhapk

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val dato1 = this.intent.extras
        val idPerfil = dato1!!.getString("idPerfil")
        val dato2 = this.intent.extras
        val numero = dato2!!.getString("numero")
        val dato3 = this.intent.extras
        val nombre = dato3!!.getString("nombre")
        val dato4 = this.intent.extras
        val contraseña = dato4!!.getString("contrasena")
        val dato5 = this.intent.extras
        val dinero = dato5!!.getInt("dinero")


        val botontrans = findViewById<ImageButton>(R.id.bottontransferencia)
        val botonagregar= findViewById<ImageButton>(R.id.bottonConsignar)
        val botonperfil = findViewById<ImageButton>(R.id.bottonPerfil)
        val botonregresar = findViewById<ImageButton>(R.id.bottonSalir)

        Toast.makeText(this,"${dinero}", Toast.LENGTH_LONG).show()


        botontrans.setOnClickListener {
            val intent = Intent(this, MainActivityTransferencia::class.java)
            intent.putExtra("idPerfil", idPerfil)
            intent.putExtra("dinero", dinero)
            startActivity(intent)
        }
        botonagregar.setOnClickListener {
            val intent = Intent(this, MainActivityConsignar::class.java)
            intent.putExtra("idPerfil", idPerfil)
            intent.putExtra("dinero", dinero)
            startActivity(intent)
        }
        botonperfil.setOnClickListener {
            val intent = Intent(this, MainActivityUsuario::class.java)
            intent.putExtra("idPerfil", idPerfil)
            startActivity(intent)
        }
        botonregresar.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }


    }
}