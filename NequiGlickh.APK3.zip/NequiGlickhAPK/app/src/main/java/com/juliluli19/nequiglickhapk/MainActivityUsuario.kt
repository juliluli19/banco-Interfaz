package com.juliluli19.nequiglickhapk

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivityUsuario : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_usuario)


        val dato1 = this.intent.extras
        val idPerfil = dato1!!.getString("idPerfil")

        val textnombre = findViewById<TextView>(R.id.textnombre)
        val textnumero = findViewById<TextView>(R.id.textnumero)
        val textcontrasena = findViewById<TextView>(R.id.textcontrasena)
        val textdinero = findViewById<TextView>(R.id.textdinero)
        val textid = findViewById<TextView>(R.id.textViewid)


        val botonregresar = findViewById<Button>(R.id.butonregresar)
        val botonaeditar = findViewById<Button>(R.id.buttonaEditar)

        val adminSQLlite= AdminSQLlite(this, "MisPerfiles", null,1)
        val bd = adminSQLlite.writableDatabase
        val consulta = bd.rawQuery("select idPerfil,numero,nombre,contraseña,dinero From perfiles where idPerfil=${idPerfil}",null)
        if(consulta.moveToFirst()){
            textid.text = consulta.getString(0)
            textnumero.text = consulta.getString(1)
            textnombre.text = consulta.getString(2)
            textcontrasena.text = consulta.getString(3)
            textdinero.text = consulta.getString(4)
        }else{
            Toast.makeText(this,"El producto no esta :c", Toast.LENGTH_LONG).show()
        }
        bd.close()

        botonaeditar.setOnClickListener{
            val intent = Intent(this, MainActivityEditarUsuario::class.java)
            intent.putExtra("idPerfil", idPerfil)
            startActivity(intent)
        }


        botonregresar.setOnClickListener{

            val intent = Intent(this, MainActivity2::class.java)
            intent.putExtra("idPerfil", idPerfil)
            startActivity(intent)
        }





    }
}