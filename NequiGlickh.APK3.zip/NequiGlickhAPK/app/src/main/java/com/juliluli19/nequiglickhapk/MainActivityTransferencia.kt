package com.juliluli19.nequiglickhapk

import android.content.ContentValues
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivityTransferencia : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_transferencia)

        val dato1 = this.intent.extras
        val idPerfil = dato1!!.getString("idPerfil")


        val idtransa = findViewById<EditText>(R.id.idtransa)
        val monto = findViewById<EditText>(R.id.monto)

        val botontrans = findViewById<Button>(R.id.buttontransferir)


        botontrans.setOnClickListener {
            val adminSQLlite = AdminSQLlite(this, "MisPerfiles", null,1)
            val bd = adminSQLlite.writableDatabase

            val consulta = bd.rawQuery("select dinero From perfiles where numero=${idtransa.text.toString()}",null)


            if(consulta.moveToFirst()){
                val dinerotrans = consulta.getInt(0)

                val dineroAConsignarTexto: String = monto.text.toString()
                val dineroAConsignar: Int = if (dineroAConsignarTexto.isNotEmpty()) {
                    dineroAConsignarTexto.toIntOrNull() ?: 0
                } else {
                    0
                }

                val dinerotransferencia =  dinerotrans + dineroAConsignar

                val cambiar = ContentValues()

                cambiar.put("dinero", dinerotransferencia)

                val editar = bd.update("perfiles", cambiar,"numero=${idtransa.text.toString()}",null)

                Toast.makeText(this,"Se transfirio ${dinerotransferencia} a ${idtransa}:c", Toast.LENGTH_LONG).show()

                val intent = Intent(this, MainActivity2::class.java)
                intent.putExtra("idPerfil", idPerfil)
                intent.putExtra("dinero", dinerotransferencia)
                startActivity(intent)

            }else{
                Toast.makeText(this,"El producto no esta :c", Toast.LENGTH_LONG).show()
                val intent = Intent(this, MainActivity2::class.java)
                intent.putExtra("idPerfil", idPerfil)
                startActivity(intent)
            }
            bd.close()


        }

    }
}