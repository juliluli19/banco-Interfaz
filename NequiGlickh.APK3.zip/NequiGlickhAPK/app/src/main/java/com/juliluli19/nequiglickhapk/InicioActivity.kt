package com.juliluli19.nequiglickhapk

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class InicioActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inicio)

        val numero = findViewById<EditText>(R.id.editText)

        val buttonentrar = findViewById<Button>(R.id.buttonentrar)
        val buttonDelete = findViewById<Button>(R.id.buttondelete)

        val button0 = findViewById<Button>(R.id.button0)
        val button1 = findViewById<Button>(R.id.button1)
        val button2 = findViewById<Button>(R.id.button2)
        val button3 = findViewById<Button>(R.id.button3)
        val button4 = findViewById<Button>(R.id.button4)
        val button5 = findViewById<Button>(R.id.button5)
        val button6 = findViewById<Button>(R.id.button6)
        val button7 = findViewById<Button>(R.id.button7)
        val button8 = findViewById<Button>(R.id.button8)
        val button9 = findViewById<Button>(R.id.button9)
        val buttoncoma = findViewById<Button>(R.id.buttoncoma)


        val buttonArray = arrayOf(button0, button1, button2, button3, button4, button5, button6, button7, button8, button9)

            buttonentrar.setOnClickListener {

                val username = numero.text.toString()
                val adminSQLlite= AdminSQLlite(this, "MisPerfiles", null,1)
                val bd = adminSQLlite.writableDatabase
                val consulta = bd.rawQuery("select idPerfil,numero,nombre,contraseña,dinero From perfiles where contraseña=${numero.text.toString()}",null)
                if(consulta.moveToFirst()){
                    if (isValidUsername(username)) {
                        if (username == consulta.getString(3)) {
                            // Si el usuario es "1234", abrir la actividad Inicio
                            val intent = Intent(this, MainActivity2::class.java)
                            intent.putExtra("idPerfil", consulta.getString(0))
                            intent.putExtra("numero", consulta.getString(1))
                            intent.putExtra("nombre", consulta.getString(2))
                            intent.putExtra("contraseña", consulta.getString(3))
                            intent.putExtra("dinero", consulta.getInt(4))
                            startActivity(intent)
                        } else {
                            // El nombre de usuario es válido pero no es "1234", mostrar un mensaje
                            Toast.makeText(this,"La clave no es válida", Toast.LENGTH_LONG).show()
                        }
                    } else {
                        // El nombre de usuario no es válido, mostrar un mensaje de error
                        Toast.makeText(this,"El nombre de usuario no es válido", Toast.LENGTH_LONG).show()
                    }
                }else{
                    Toast.makeText(this,"El numero no esta :c", Toast.LENGTH_LONG).show()
                    numero.setText("")
                }
                bd.close()


            }

            // Manejar clics en los botones
            for (button in buttonArray) {
                button.setOnClickListener {
                    appendText(button.text.toString(), numero)
                }
            }

            // Manejar clic en el botón de eliminación
            buttonDelete.setOnClickListener {
                removeLastCharacter(numero)
            }

    }

    private fun isValidUsername(username: String): Boolean {
        // Aquí puedes agregar la lógica de validación del nombre de usuario según tus requisitos
        // Por ejemplo, verificar en una base de datos o mediante algún otro método
        return username.isNotEmpty()
    }


    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }


    private fun appendText(value: String, editText: EditText) {
        val currentText = editText.text.toString()
        editText.setText(currentText + value)
    }

    private fun removeLastCharacter(editText: EditText) {
        val currentText = editText.text.toString()
        if (currentText.isNotEmpty()) {
            val newText = currentText.substring(0, currentText.length - 1)
            editText.setText(newText)
        }
    }
}
