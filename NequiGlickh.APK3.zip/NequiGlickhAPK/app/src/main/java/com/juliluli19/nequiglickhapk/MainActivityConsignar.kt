package com.juliluli19.nequiglickhapk

import android.content.ContentValues
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivityConsignar : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_consignar)

        val dineroaconsignar = findViewById<EditText>(R.id.dinero)
        val consignardinero = findViewById<Button>(R.id.consignardinero)

        val dineroaretirar = findViewById<EditText>(R.id.dineroaretirar)
        val Retirardinero = findViewById<Button>(R.id.retirardinero)


        val dato1 = this.intent.extras
        val idPerfil = dato1!!.getString("idPerfil")

        val dato5 = this.intent.extras
        val dinero = dato5!!.getInt("dinero")


        Toast.makeText(this,"${dinero}", Toast.LENGTH_LONG).show()

        consignardinero.setOnClickListener {
            val adminSQLlite = AdminSQLlite(this, "MisPerfiles", null,1)
            val bd = adminSQLlite.writableDatabase

            val dineroAConsignarTexto: String = dineroaconsignar.text.toString()
            val dineroAConsignar: Int = if (dineroAConsignarTexto.isNotEmpty()) {
                dineroAConsignarTexto.toIntOrNull() ?: 0
            } else {
                0
            }

            val suma =  dinero + dineroAConsignar

            val cambiar = ContentValues()

            cambiar.put("dinero", suma)

            val editar = bd.update("perfiles", cambiar,"idPerfil=${idPerfil}",null)

            bd.close()

            if (editar==1){
                Toast.makeText(this,"El producto cambio :D", Toast.LENGTH_LONG).show()
            }else{
                Toast.makeText(this,"El producto no cambio :c", Toast.LENGTH_LONG).show()
            }
            val intent = Intent(this, MainActivity2::class.java)
            intent.putExtra("idPerfil", idPerfil)
            intent.putExtra("dinero", suma)
            startActivity(intent)

        }


        Retirardinero.setOnClickListener {
            val adminSQLlite = AdminSQLlite(this, "MisPerfiles", null,1)
            val bd = adminSQLlite.writableDatabase

            val dineroAConsignarTexto: String = dineroaretirar.text.toString()
            val dineroAConsignar: Int = if (dineroAConsignarTexto.isNotEmpty()) {
                dineroAConsignarTexto.toIntOrNull() ?: 0
            } else {
                0
            }

            val resta =  dinero - dineroAConsignar

            val cambiar = ContentValues()

            cambiar.put("dinero", resta)

            val editar = bd.update("perfiles", cambiar,"idPerfil=${idPerfil}",null)

            bd.close()

            if (editar==1){
                Toast.makeText(this,"El producto cambio :D", Toast.LENGTH_LONG).show()
            }else{
                Toast.makeText(this,"El producto no cambio :c", Toast.LENGTH_LONG).show()
            }
            val intent = Intent(this, MainActivity2::class.java)
            intent.putExtra("idPerfil", idPerfil)
            intent.putExtra("dinero", resta)
            startActivity(intent)

        }


    }
}