package com.juliluli19.nequiglickhapk

class Suma(numero1:Double, numero2: Double):Operacion(numero1,numero2) {
    override fun operar() {
        resultado= numero1+numero2
    }
}
class Resta(numero1:Double, numero2: Double):Operacion(numero1,numero2) {
    override fun operar() {
        resultado= numero1-numero2
    }
}

fun main() {
    val sumar = Suma(1.0,1.0)
    sumar.operar()
    sumar.imprimir()

    val restar = Resta(3.4,2.0)
    restar.operar()
    restar.imprimir()
}