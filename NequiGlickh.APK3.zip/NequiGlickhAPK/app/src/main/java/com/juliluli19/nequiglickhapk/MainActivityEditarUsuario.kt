package com.juliluli19.nequiglickhapk

import android.content.ContentValues
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivityEditarUsuario : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_editar_usuario)

        val dato1 = this.intent.extras
        val idPerfil = dato1!!.getString("idPerfil")


        val numero = findViewById<EditText>(R.id.editTextNumero3)
        val nombre = findViewById<EditText>(R.id.editTextNombre3)
        val clave = findViewById<EditText>(R.id.editTextContrasena3)


        val botonregresar = findViewById<Button>(R.id.butonregresar2)
        val botonEliminar = findViewById<Button>(R.id.buttonEliminar2)
        val botonEditar = findViewById<Button>(R.id.buttonEditar2)

        Toast.makeText(this,"${idPerfil}", Toast.LENGTH_LONG).show()

        botonEditar.setOnClickListener {

            val adminSQLlite= AdminSQLlite(this, "MisPerfiles", null,1)
            val bd = adminSQLlite.writableDatabase
            val cambiar = ContentValues()

            cambiar.put("numero",numero.text.toString())
            cambiar.put("contraseña",clave.text.toString())
            cambiar.put("nombre",nombre.text.toString())
            val editar = bd.update("perfiles", cambiar,"idPerfil=${idPerfil}",null)

            bd.close()

            if (editar==1){
                Toast.makeText(this,"Los datos se cambiaron :D", Toast.LENGTH_LONG).show()
                val intent = Intent(this, MainActivityUsuario::class.java)
                intent.putExtra("idPerfil", idPerfil)
                startActivity(intent)

            }else{
                Toast.makeText(this,"El producto no cambio :c", Toast.LENGTH_LONG).show()
            }


        }

        botonEliminar.setOnClickListener {
            val adminSQLlite= AdminSQLlite(this, "MisPerfiles", null,1)
            val bd = adminSQLlite.writableDatabase
            val eliminar = bd.delete("perfiles","idPerfil=${idPerfil}",null)

            bd.close()
            if(eliminar==1){
                Toast.makeText(this,"El producto se elimino :D", Toast.LENGTH_LONG).show()
            }else{
                Toast.makeText(this,"El producto no se elimino:D", Toast.LENGTH_LONG).show()
            }

        }


        botonregresar.setOnClickListener{

            val intent = Intent(this, MainActivity2::class.java)
            intent.putExtra("idPerfil", idPerfil)
            startActivity(intent)
        }


    }
}