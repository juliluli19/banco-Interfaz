package com.juliluli19.nequiglickhapk

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val numero = findViewById<EditText>(R.id.editTextNumber1)

        val boton = findViewById<Button>(R.id.botoninicio)
        val botonregistro = findViewById<Button>(R.id.pararegistro)
        val botonadmin = findViewById<Button>(R.id.buttonAdmin)


        boton.setOnClickListener {
            val username = numero.text.toString()
            val adminSQLlite= AdminSQLlite(this, "MisPerfiles", null,1)
            val bd = adminSQLlite.writableDatabase

            val consulta = bd.rawQuery("select numero From perfiles where numero=${numero.text.toString()}",null)
                if(consulta.moveToFirst()){
                        if (isValidUsername(username)){
                            if (username == consulta.getString(0)){
                                // Si el usuario es "1234", abrir la actividad Inicio
                                val intent = Intent(this, InicioActivity::class.java)
                                startActivity(intent)
                            } else {
                                // El nombre de usuario es válido pero no es "1234", mostrar un mensaje
                                showToast("Este número no está registrado")
                            }
                        } else {
                            // El nombre de usuario no es válido, mostrar un mensaje de error
                            numero.error = "Nombre de usuario no válido"
                        }
                }else{
                    Toast.makeText(this,"El numero no esta :c", Toast.LENGTH_LONG).show()
                    numero.setText("")
                }
            bd.close()
        }
        botonregistro.setOnClickListener{
            val intent = Intent(this, MainActivityRegistro::class.java)
            startActivity(intent)
        }
        botonadmin.setOnClickListener{
            val intent = Intent(this, MainActivityPerfil::class.java)
            startActivity(intent)
        }
    }

    private fun isValidUsername(username: String): Boolean {
        // Aquí puedes agregar la lógica de validación del nombre de usuario según tus requisitos
        // Por ejemplo, verificar en una base de datos o mediante algún otro método
        return username.isNotEmpty()
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
