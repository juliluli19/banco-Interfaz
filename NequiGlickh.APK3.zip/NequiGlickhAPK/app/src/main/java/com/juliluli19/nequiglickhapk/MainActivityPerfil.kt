package com.juliluli19.nequiglickhapk

import android.content.ContentValues
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivityPerfil : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_perfil)

        val idPerfil = findViewById<EditText>(R.id.editTextIdPerfil)
        val numero = findViewById<EditText>(R.id.editTextNumero)
        val nombre = findViewById<EditText>(R.id.editTextNombre)
        val clave = findViewById<EditText>(R.id.editTextContrasena)

        val botonConsultar = findViewById<Button>(R.id.buttonConsultar)
        val botonRegistrar = findViewById<Button>(R.id.buttonRegistrar)
        val botonEliminar = findViewById<Button>(R.id.buttonEliminar)
        val botonEditar = findViewById<Button>(R.id.buttonEditar)


        botonRegistrar.setOnClickListener{
            val adminSQLlite = AdminSQLlite(this, "MisPerfiles", null,1)
            val bd = adminSQLlite.writableDatabase
            val registro = ContentValues()
            registro.put("idPerfil",idPerfil.text.toString())
            registro.put("numero",numero.text.toString())
            registro.put("contrasena",clave.text.toString())
            registro.put("nombre",nombre.text.toString())
            bd.insert("perfiles",null, registro)
            bd.close()

            idPerfil.setText("")
            numero.setText("")
            nombre.setText("")
            clave.setText("")
            Toast.makeText(this,"El producto fue reguistrado", Toast.LENGTH_LONG).show()
        }

        botonConsultar.setOnClickListener {

            val adminSQLlite= AdminSQLlite(this, "MisPerfiles", null,1)
            val bd = adminSQLlite.writableDatabase
            val consulta = bd.rawQuery("select idPerfil,numero,nombre,contraseña From perfiles where idPerfil=${idPerfil.text.toString()}",null)

            if(consulta.moveToFirst()){
                idPerfil.setText(consulta.getString(0))
                numero.setText(consulta.getString(1))
                nombre.setText(consulta.getString(2))
                clave.setText(consulta.getString(3))
            }else{
                Toast.makeText(this,"El producto no esta :c", Toast.LENGTH_LONG).show()
                idPerfil.setText("")
                numero.setText("")
                nombre.setText("")
                clave.setText("")
            }
            bd.close()
        }


        botonEditar.setOnClickListener {
            val adminSQLlite= AdminSQLlite(this, "MisPerfiles", null,1)
            val bd = adminSQLlite.writableDatabase
            val cambiar = ContentValues()
            cambiar.put("numero",numero.text.toString())
            cambiar.put("contraseña",clave.text.toString())
            cambiar.put("nombre",nombre.text.toString())
            val editar = bd.update("perfiles", cambiar,"idPerfil=${idPerfil.text.toString()}",null)

            bd.close()

            if (editar==1){
                Toast.makeText(this,"El producto cambio :D", Toast.LENGTH_LONG).show()
                idPerfil.setText("")
                numero.setText("")
                nombre.setText("")
                clave.setText("")
            }else{
                Toast.makeText(this,"El producto no cambio :c", Toast.LENGTH_LONG).show()
            }


        }

        botonEliminar.setOnClickListener {
            val adminSQLlite= AdminSQLlite(this, "MisPerfiles", null,1)
            val bd = adminSQLlite.writableDatabase
            val eliminar = bd.delete("perfiles","idPerfil=${idPerfil.text.toString()}",null)

            bd.close()
            if(eliminar==1){
                Toast.makeText(this,"El producto se elimino :D", Toast.LENGTH_LONG).show()
                idPerfil.setText("")
                numero.setText("")
                nombre.setText("")
                clave.setText("")
            }else{
                Toast.makeText(this,"El producto no se elimino:D", Toast.LENGTH_LONG).show()
            }

        }
    }
}