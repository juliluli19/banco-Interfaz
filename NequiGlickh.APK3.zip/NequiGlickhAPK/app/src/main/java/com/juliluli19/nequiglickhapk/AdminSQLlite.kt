package com.juliluli19.nequiglickhapk

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteDatabase.CursorFactory
import android.database.sqlite.SQLiteOpenHelper

class AdminSQLlite(contexto:Context, nombre:String, cursor:CursorFactory?, version:Int):SQLiteOpenHelper(contexto,nombre,cursor,version){
    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL("create table perfiles(idPerfil Int primary key,numero real,contrasena real,nombre Text,dinero Int)")
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        TODO("Not yet implemented")
    }


}